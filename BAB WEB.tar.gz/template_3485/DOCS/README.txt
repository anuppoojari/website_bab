========================



PATROS HTML5 Template

 1.0



========================

Author: ATIS




Twitter: 
https://twitter.com/ATIS_Shpk

Facebook: https://www.facebook.com/AtisAlbania

LinkedIn:http://www.linkedin.com/company/albanian-telecommunication-and-information-services
 
Website: http://atis.al/




========================

Link removal:

Please contact us if you want to remove the attribution in the footer. 
Template by: www.atis.al


========================


License



- Please refer to the LICENSE.txt file



========================

This projects uses open-source components:

Bootstrap - http://getbootstrap.com
Font Awesome Icons - http://fortawesome.github.io/Font-Awesome/
jQuery QuickSand - https://github.com/razorjack/quicksand/

Ajax Contact Form by Erland Muchasaj -  https://al.linkedin.com/pub/erland-muchasaj/57/aa2/1b6

========================

Image credits:

http://www.unsplash.com
Photo: "unsplash1.jpg" - Author: Daniela Cuevas
Photo: "unsplash2.jpg" - Author: Luis Llerena
Photo: "unsplash3.jpg" - Author: Luis Llerena
Photo: "unsplash4.jpg" - Author: Blair Fraser
Photo: "unsplash5.jpg" - Author: William Iven
Photo: "unsplash6.jpg" - Author: Ilya
Photo: "blog1.jpg" - Author: Ksenia Kudelkina
Photo: "blog2.jpg" - Author: Dirk Sebregts
Photo: "blog3.jpg" - Author: Sebastian Boguszewicz
Photo: "blog-photo1.jpg" - Author: Rula Sibai
Photo: "blog-photo2.jpg" - Author: Jeff Sheldon
Photo: "blog-photo3.jpg" - Author: Jeff Sheldon
Photo: "port1.jpg" - Author: Jeff Sheldon
Photo: "port2.jpg" - Author: Jay Wennington
Photo: "port3.jpg" - Author: Drew Patrick
Photo: "port4.jpg" - Author: Pawel Kadysz
Photo: "port5.jpg" - Author: Aleks Dorohovich
Photo: "port6.jpg" - Author: Glen Carrie

https://pixabay.com/
Photo: "person1.jpg" - Author: Unsplash

